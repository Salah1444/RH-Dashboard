<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('grade', function (Blueprint $table) {
            $table->id('id_grade');
            $table->string('GRADE', 50)->nullable();
            $table->string('Lib_grade_AR', 200)->nullable();
            $table->string('Lib_grade_FR', 200)->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('grade');
    }
};
