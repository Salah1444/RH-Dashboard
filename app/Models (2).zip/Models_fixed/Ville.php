<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Ville extends Model
{
    public function employees()
    {
        return $this->hasMany(Employe::class);
    }
}
